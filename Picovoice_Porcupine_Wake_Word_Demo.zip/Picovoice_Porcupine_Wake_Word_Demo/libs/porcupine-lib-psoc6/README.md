## Demos

Check out the [Porcupine demo for PSoC6](https://github.com/Picovoice/porcupine-demo-psoc6) to see what it looks like to use Porcupine in an embedded project!
